window.addEventListener("DOMContentLoaded", myEvents);

function myEvents() {
  getWeatherReport("Mumbai");
  document.getElementById("searchBtn").addEventListener("click", getUserInput);
}

// dom load -> myEvents -> getWeatherReport

function getUserInput() {
  var value = document.getElementById("searchCity").value;
  getWeatherReport(value);
}

async function getWeatherReport(cityName) {
  var URL = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=8ff3b783b61261fc8bade7e97d3205fe`;
  var response = await fetch(URL);
  var data = await response.json();
  console.log(data);
  printDetails(
    data.name,
    data.main.temp,
    data.weather[0].main,
    data.weather[0].icon
  );
}

var weekDays = {
  0: "sun",
  1: "Mon",
  2: "tues",
  3: "wed",
  4: "thru",
  5: "friday",
  6: "sat",
};

function printDetails(cityName, temp, detail, image, humidity, wind, pressure) {
  var date = new Date();
  document.getElementById("day").innerText = weekDays[date.getDay()];
  document.getElementById("cityName").innerText = cityName;
  document.getElementById("temp").innerHTML =
    parseInt(temp - 273.15) + " &deg; C";
  document.getElementById("detail").innerText = detail;
  var div = document.getElementById("weatherImg");
  div.innerHTML = `<img src=https://openweathermap.org/img/wn/${image}.png />`;
}

// string templates || string literals
